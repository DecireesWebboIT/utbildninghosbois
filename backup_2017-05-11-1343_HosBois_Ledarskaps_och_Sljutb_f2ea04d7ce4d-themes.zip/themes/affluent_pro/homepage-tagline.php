<?php cpotheme_block('home_tagline', 'tagline primary-color-bg dark', 'container'); ?>
